package com.mytube.app

data class Video(
    val id: String,
    val title: String,
    val channel: String = "YouTube creator",
    val description: String = "",
    val thumbnail: String = "https://i.ytimg.com/vi/$id/hqdefault.jpg"
)
