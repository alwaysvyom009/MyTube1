# MyTube — Android Studio source project

MyTube is an original Kotlin + Jetpack Compose video discovery app starter built after inspecting the supplied YouTube Pro APK. It does **not** reuse or redistribute the APK's proprietary code, branding, scripts, or modified YouTube components.

## What the supplied APK inspection found

- APK archive size: approximately 19 MB; 2,407 ZIP entries.
- Five DEX bytecode files (`classes.dex` through `classes5.dex`).
- Kotlin/AndroidX application components and coroutine libraries.
- ExoPlayer 2.18.7 strings/classes.
- Vanced-related package/module strings and YouTube web-player integration strings.
- Search, Shorts, playlist, and player-related code strings.
- This is a static archive/DEX-string inspection, not a complete decompilation. Original source names/comments and build project cannot be recovered reliably from an APK alone.

## Features in this original starter

- Compose Material 3 interface with Home, Shorts-style discovery, Library, and Settings tabs.
- YouTube Data API v3 search (requires your own API key).
- YouTube embedded player using the supported embed endpoint.
- Local saved-video IDs and dark/light appearance preference.
- Responsive video list and player screen.

The starter UI uses local demo entries until live search is configured. Demo entries are placeholders and are not a full replacement for a live recommendation feed.

## Build in Android Studio

1. Install Android Studio with Android SDK 35 and JDK 17.
2. Open this `MyTube` folder as a project and allow Gradle sync.
3. To enable search, create/edit `local.properties` in the project root and add:

   ```properties
   sdk.dir=/your/android/sdk/path
   YOUTUBE_API_KEY=YOUR_YOUTUBE_DATA_API_V3_KEY
   ```

   Android Studio normally creates `sdk.dir` for you. Keep your API key private; do not commit `local.properties`.
4. Enable **YouTube Data API v3** in Google Cloud Console, create an API key, and restrict it appropriately.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Notes and limitations

- A YouTube Data API key is not included. Search will show a setup message until you add one.
- Playback is through YouTube's embedded player. Availability, ads, playback controls, and content restrictions are governed by YouTube and the video's embed settings.
- The app does not download videos, bypass ads, extract streams, or bypass YouTube restrictions.
- The Shorts tab is currently a lightweight discovery placeholder, not a complete Shorts feed.
- For production, move API calls behind a secure backend or use suitable key restrictions and review the current YouTube API Services Terms and Developer Policies.

## Project structure

```text
MyTube/
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/mytube/app/
    MainActivity.kt
    Video.kt
    YouTubeApi.kt
  app/src/main/res/values/styles.xml
  app/build.gradle.kts
  build.gradle.kts
  settings.gradle.kts
```

## Build an APK using only your phone (no AndroidIDE)

This project includes a GitHub Actions cloud build. The APK is built on GitHub's servers, not on your phone.

1. In Chrome, open https://github.com and sign in (create a free account if needed).
2. Create a **public** repository named `MyTube` (public repositories can use GitHub-hosted Actions on the free plan within the included limits).
3. Extract this ZIP on your phone with a file manager such as ZArchiver.
4. Upload the **contents inside the `MyTube` folder** to the repository root, preserving folders. The `.github/workflows/build-apk.yml` file is important. If the GitHub mobile upload screen cannot upload folders, switch Chrome to **Desktop site** or use a computer once to upload the project.
5. Open the repository's **Actions** tab. Select **Build MyTube APK** and tap **Run workflow** if it has not started automatically.
6. Wait for the workflow to finish with a green check mark. Open that run, scroll to **Artifacts**, and download `MyTube-debug-APK`.
7. Extract the artifact ZIP; inside is `app-debug.apk`. Tap it to install. Allow Chrome/File Manager to install unknown apps if Android asks.

### 32-bit and 64-bit compatibility

The starter app currently uses Kotlin/Java and Android framework APIs, with no app-bundled native `.so` libraries. The resulting APK is therefore not restricted to ARM 64-bit and is expected to install on both 32-bit ARM and 64-bit ARM Android devices that meet `minSdk 23`. This is not a guarantee for every device; test the generated APK on the target phone.

### Important

- GitHub Actions builds the APK remotely; your phone does not need Gradle, AndroidIDE, or Android SDK.
- YouTube live search needs your own YouTube Data API v3 key. The app still builds without it; search shows a setup message until configured.
- This project is a starter app. YouTube playback is via the official embedded player and follows YouTube's embed restrictions.
